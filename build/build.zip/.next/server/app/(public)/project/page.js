(() => {
var exports = {};
exports.id = 103;
exports.ids = [103];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 7342:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/no-ssr-error.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 4053:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 8976:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "metadata": () => (/* binding */ metadata),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2315);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2333);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2885);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9505);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(683);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3269);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5746);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8208);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(public)',
        {
        children: [
        'project',
        {
        children: ['', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 9909, 23)), "/home/stehanget/projects/nextjs/lioke-rebrand/app/(public)/project/page.js"]}]
      },
        {
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6271, 23)), "/home/stehanget/projects/nextjs/lioke-rebrand/app/(public)/layout.js"],
'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2339)), "/home/stehanget/projects/nextjs/lioke-rebrand/app/(public)/head.js"],
        }
      ]
      },
        {
          
        }
      ]
      }.children;
    const metadata = [{
          type: 'layout',
          layer: 1,
          mod: () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6271, 23)),
          path: "/home/stehanget/projects/nextjs/lioke-rebrand/app/(public)/layout.js",
        },{
          type: 'page',
          layer: 2,
          mod: () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 9909, 23)),
          path: "/home/stehanget/projects/nextjs/lioke-rebrand/app/(public)/project/page.js",
        },];
    const pages = ["/home/stehanget/projects/nextjs/lioke-rebrand/app/(public)/project/page.js"];

    
    
    
    

    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
  

/***/ }),

/***/ 5253:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6315))

/***/ }),

/***/ 9909:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(4353);
module.exports = createProxy("/home/stehanget/projects/nextjs/lioke-rebrand/app/(public)/project/page.js");


/***/ }),

/***/ 6315:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(8421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1621);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./components/icon-project-desc/index.js



function IconButtonDescription(props) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-primary p-2 rounded-lg",
        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
            src: `${props.src}`,
            width: 32,
            height: 32,
            className: "w-8 h-8"
        })
    });
}

;// CONCATENATED MODULE: ./components/select-category-project/index.js


function index() {
    return /*#__PURE__*/ _jsxs(_Fragment, {
        children: [
            /*#__PURE__*/ _jsxs("div", {
                className: "flex space-x-8 mt-16 flex-row px-16 font-medium ",
                children: [
                    /*#__PURE__*/ _jsx("p", {
                        className: "font-extrabold",
                        children: "All"
                    }),
                    /*#__PURE__*/ _jsx("p", {
                        children: "Web"
                    }),
                    /*#__PURE__*/ _jsx("p", {
                        children: "Mobile"
                    }),
                    /*#__PURE__*/ _jsx("p", {
                        children: "Paper"
                    })
                ]
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "flex h-0.5 mt-4 bg-gray-200 w-auto mx-16"
            })
        ]
    });
}

// EXTERNAL MODULE: ./components/project-card/index.js
var project_card = __webpack_require__(442);
// EXTERNAL MODULE: ./recoil/atom.js
var atom = __webpack_require__(6464);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/transitions/transition.js + 4 modules
var transition = __webpack_require__(6235);
// EXTERNAL MODULE: ./node_modules/@headlessui/react/dist/components/dialog/dialog.js + 21 modules
var dialog = __webpack_require__(5990);
// EXTERNAL MODULE: ./node_modules/recoil/cjs/index.js
var cjs = __webpack_require__(6779);
;// CONCATENATED MODULE: ./components/modal-desc/modal-skill/list-skill/index.js


function ListSkill() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                class: "flex items-center text-lg font-regular text-gray-900 dark:text-white",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        class: "flex w-3 h-3 bg-secondary rounded-full mr-1.5 flex-shrink-0"
                    }),
                    "Laravel"
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                class: " my-4 bg-secondary border-1 border-secondary rounded "
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/modal-desc/modal-skill/index.js







function ModalSkill(props) {
    let [isOpen, setIsOpen] = (0,cjs/* useRecoilState */.FV)(atom/* showModalSkill */.uv);
    return /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition */.u, {
        appear: true,
        show: isOpen,
        as: react_.Fragment,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog */.V, {
            as: "div",
            className: "relative z-10",
            onClose: ()=>setIsOpen(false),
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition.Child */.u.Child, {
                    as: react_.Fragment,
                    enter: "ease-out duration-300",
                    enterFrom: "opacity-0",
                    enterTo: "opacity-100",
                    leave: "ease-in duration-200",
                    leaveFrom: "opacity-100",
                    leaveTo: "opacity-0",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "fixed inset-0 bg-black bg-opacity-25"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "fixed inset-0 overflow-y-auto",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex min-h-full items-center justify-center p-4 text-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition.Child */.u.Child, {
                            as: react_.Fragment,
                            enter: "ease-out duration-300",
                            enterFrom: "opacity-0 scale-95",
                            enterTo: "opacity-100 scale-100",
                            leave: "ease-in duration-200",
                            leaveFrom: "opacity-100 scale-100",
                            leaveTo: "opacity-0 scale-95",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog.Panel */.V.Panel, {
                                className: "w-full max-w-sm transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog.Title */.V.Title, {
                                        as: "h3",
                                        className: "leading-6 text-gray-900 flex flex-row items-center justify-center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                width: 36,
                                                height: 36,
                                                src: "/modal-desc/skill-modal.svg"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "font-semibold text-xl text-secondary ml-2",
                                                children: "SKILLS"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "mt-2",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ListSkill, {})
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "mt-8 flex justify-center",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            type: "button",
                                            onClick: ()=>setIsOpen(false),
                                            className: "inline-flex justify-center rounded-md border border-transparent bg-secondary/50 px-4 py-2 text-sm font-medium text-gray-600 hover:bg-secondary hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary focus-visible:ring-offset-2",
                                            children: "Got it, thanks!"
                                        })
                                    })
                                ]
                            })
                        })
                    })
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./components/modal-desc/modal-work/list-work/index.js


function ListWork() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
        class: "mb-10 ml-4",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                class: "absolute w-3 h-3 bg-secondary rounded-full -left-1.5 border border-white dark:border-gray-900 dark:bg-gray-700"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                class: "text-lg font-semibold text-gray-900 dark:text-white",
                children: "Application UI code in Tailwind CSS"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("time", {
                class: "mb-1 text-sm font-normal leading-none text-gray-400 dark:text-gray-500",
                children: "February 2022"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                class: "mb-4 text-base font-normal text-gray-500 dark:text-gray-400",
                children: "Get access to over 20+ pages including a dashboard layout, charts, kanban board, calendar, and pre-order E-commerce & Marketing pages."
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/modal-desc/modal-work/index.js







function ModalWork() {
    let [isOpen, setIsOpen] = (0,cjs/* useRecoilState */.FV)(atom/* showModalWork */.sD);
    return /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition */.u, {
        appear: true,
        show: isOpen,
        as: react_.Fragment,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog */.V, {
            as: "div",
            className: "relative z-10",
            onClose: ()=>setIsOpen(false),
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition.Child */.u.Child, {
                    as: react_.Fragment,
                    enter: "ease-out duration-300",
                    enterFrom: "opacity-0",
                    enterTo: "opacity-100",
                    leave: "ease-in duration-200",
                    leaveFrom: "opacity-100",
                    leaveTo: "opacity-0",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "fixed inset-0 bg-black bg-opacity-25"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "fixed inset-0 overflow-y-auto",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex min-h-full items-center justify-center p-4 text-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition.Child */.u.Child, {
                            as: react_.Fragment,
                            enter: "ease-out duration-300",
                            enterFrom: "opacity-0 scale-95",
                            enterTo: "opacity-100 scale-100",
                            leave: "ease-in duration-200",
                            leaveFrom: "opacity-100 scale-100",
                            leaveTo: "opacity-0 scale-95",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog.Panel */.V.Panel, {
                                className: "w-full max-w-lg transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog.Title */.V.Title, {
                                        as: "h3",
                                        className: "leading-6 text-gray-900 flex flex-row items-center justify-center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                width: 36,
                                                height: 36,
                                                src: "/modal-desc/work-modal.svg"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "font-semibold text-xl text-secondary ml-2",
                                                children: "Work Experience"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "mt-8",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ol", {
                                            class: "relative border-l border-secondary dark:border-gray-700",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(ListWork, {}),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ListWork, {}),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ListWork, {})
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "mt-8 flex justify-center",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            type: "button",
                                            onClick: ()=>setIsOpen(false),
                                            className: "inline-flex justify-center rounded-md border border-transparent bg-secondary/50 px-4 py-2 text-sm font-medium text-gray-600 hover:bg-secondary hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary focus-visible:ring-offset-2",
                                            children: "Got it, thanks!"
                                        })
                                    })
                                ]
                            })
                        })
                    })
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./components/modal-desc/modal-education/list-education/index.js


function ListEducation() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
        class: "mb-4 ml-4",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                class: "absolute w-3 h-3 bg-secondary rounded-full -left-1.5 border border-white dark:border-gray-900 dark:bg-gray-700"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                class: "text-base font-semibold text-gray-900 dark:text-white",
                children: "Mi Miftahul Huda"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                class: "mb-4 text-xs font-normal text-gray-500 dark:text-gray-400",
                children: "2021-2022"
            })
        ]
    });
}

;// CONCATENATED MODULE: ./components/modal-desc/modal-education/index.js







function ModalEducation(props) {
    let [isOpen, setIsOpen] = (0,cjs/* useRecoilState */.FV)(atom/* showModalEducation */.g);
    return /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition */.u, {
        appear: true,
        show: isOpen,
        as: react_.Fragment,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog */.V, {
            as: "div",
            className: "relative z-10",
            onClose: ()=>setIsOpen(false),
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition.Child */.u.Child, {
                    as: react_.Fragment,
                    enter: "ease-out duration-300",
                    enterFrom: "opacity-0",
                    enterTo: "opacity-100",
                    leave: "ease-in duration-200",
                    leaveFrom: "opacity-100",
                    leaveTo: "opacity-0",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "fixed inset-0 bg-black bg-opacity-25"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "fixed inset-0 overflow-y-auto",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex min-h-full items-center justify-center p-4 text-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition.Child */.u.Child, {
                            as: react_.Fragment,
                            enter: "ease-out duration-300",
                            enterFrom: "opacity-0 scale-95",
                            enterTo: "opacity-100 scale-100",
                            leave: "ease-in duration-200",
                            leaveFrom: "opacity-100 scale-100",
                            leaveTo: "opacity-0 scale-95",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog.Panel */.V.Panel, {
                                className: "w-full max-w-sm transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog.Title */.V.Title, {
                                        as: "h3",
                                        className: "leading-6 text-gray-900 flex flex-row items-center justify-center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                width: 36,
                                                height: 36,
                                                src: "/modal-desc/education-modal.svg"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "font-semibold text-xl text-secondary ml-2",
                                                children: "Education"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "mt-8",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ol", {
                                            class: "relative border-l border-secondary dark:border-gray-700",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(ListEducation, {}),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ListEducation, {}),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ListEducation, {})
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "mt-8 flex justify-center",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            type: "button",
                                            onClick: ()=>setIsOpen(false),
                                            className: "inline-flex justify-center rounded-md border border-transparent bg-secondary/50 px-4 py-2 text-sm font-medium text-gray-600 hover:bg-secondary hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary focus-visible:ring-offset-2",
                                            children: "Got it, thanks!"
                                        })
                                    })
                                ]
                            })
                        })
                    })
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./components/modal-desc/modal-interest/index.js






function ModalInterest(props) {
    let [isOpen, setIsOpen] = (0,cjs/* useRecoilState */.FV)(atom/* showModalInterest */.f3);
    return /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition */.u, {
        appear: true,
        show: isOpen,
        as: react_.Fragment,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog */.V, {
            as: "div",
            className: "relative z-10",
            onClose: ()=>setIsOpen(false),
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition.Child */.u.Child, {
                    as: react_.Fragment,
                    enter: "ease-out duration-300",
                    enterFrom: "opacity-0",
                    enterTo: "opacity-100",
                    leave: "ease-in duration-200",
                    leaveFrom: "opacity-100",
                    leaveTo: "opacity-0",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "fixed inset-0 bg-black bg-opacity-25"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "fixed inset-0 overflow-y-auto",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex min-h-full items-center justify-center p-4 text-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition.Child */.u.Child, {
                            as: react_.Fragment,
                            enter: "ease-out duration-300",
                            enterFrom: "opacity-0 scale-95",
                            enterTo: "opacity-100 scale-100",
                            leave: "ease-in duration-200",
                            leaveFrom: "opacity-100 scale-100",
                            leaveTo: "opacity-0 scale-95",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog.Panel */.V.Panel, {
                                className: "w-full max-w-lg transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog.Title */.V.Title, {
                                        as: "h3",
                                        className: "leading-6 text-gray-900 flex flex-row items-center justify-center",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                width: 36,
                                                height: 36,
                                                src: "/modal-desc/education-modal.svg"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "font-semibold text-xl text-secondary ml-2",
                                                children: "Education"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "mt-8 grid grid-cols-3 gap-2 ",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                class: "bg-secondary text-white text-xs font-medium px-3 py-2 rounded text-center self-center",
                                                children: "Art"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                class: "bg-secondary text-white text-xs font-medium px-3 py-2 rounded text-center self-center",
                                                children: "React Native"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                class: "bg-secondary text-white text-xs font-medium px-3 py-2 rounded text-center self-center",
                                                children: "Laravel"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                class: "bg-secondary text-white text-xs font-medium px-3 py-2 rounded text-center self-center ",
                                                children: "Android"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                class: "bg-secondary text-white text-xs font-medium px-3 py-2 rounded text-center self-center",
                                                children: "PHP"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                class: "bg-secondary text-white text-xs font-medium px-3 py-2 rounded text-center self-center",
                                                children: "Machine Learning"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                class: "bg-secondary text-white text-xs font-medium px-3 py-2 rounded text-center self-center",
                                                children: "Art"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "mt-8 flex justify-center",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            type: "button",
                                            onClick: ()=>setIsOpen(false),
                                            className: "inline-flex justify-center rounded-md border border-transparent bg-secondary/50 px-4 py-2 text-sm font-medium text-gray-600 hover:bg-secondary hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary focus-visible:ring-offset-2",
                                            children: "Got it, thanks!"
                                        })
                                    })
                                ]
                            })
                        })
                    })
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./components/modal-desc/modal-sosmed/index.js







function ModalSosmed(props) {
    let [isOpen, setIsOpen] = (0,cjs/* useRecoilState */.FV)(atom/* showModalSocialMedia */.o7);
    return /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition */.u, {
        appear: true,
        show: isOpen,
        as: react_.Fragment,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog */.V, {
            as: "div",
            className: "relative z-10",
            onClose: ()=>setIsOpen(false),
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition.Child */.u.Child, {
                    as: react_.Fragment,
                    enter: "ease-out duration-300",
                    enterFrom: "opacity-0",
                    enterTo: "opacity-100",
                    leave: "ease-in duration-200",
                    leaveFrom: "opacity-100",
                    leaveTo: "opacity-0",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "fixed inset-0 bg-black bg-opacity-25"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "fixed inset-0 overflow-y-auto",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex min-h-full items-center justify-center p-4 text-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(transition/* Transition.Child */.u.Child, {
                            as: react_.Fragment,
                            enter: "ease-out duration-300",
                            enterFrom: "opacity-0 scale-95",
                            enterTo: "opacity-100 scale-100",
                            leave: "ease-in duration-200",
                            leaveFrom: "opacity-100 scale-100",
                            leaveTo: "opacity-0 scale-95",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog.Panel */.V.Panel, {
                                className: "w-full max-w-lg transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex flex-row ",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(dialog/* Dialog.Title */.V.Title, {
                                                as: "h3",
                                                className: "leading-6 basis-1/2 text-gray-900 flex flex-col items-center justify-center ",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        width: 100,
                                                        height: 100,
                                                        src: "/modal-desc/sosmed-modal.svg"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                        className: "mt-8 font-semibold text-xl text-secondary ml-2",
                                                        children: "Education"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "basis-1/2 flex flex-col gap-y-4",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "flex flex-row place-items-center",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                width: 30,
                                                                height: 30,
                                                                src: "/logo-sosmed/instagram.svg"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: " font-medium text-sm ml-2",
                                                                children: "@wildan.rmza"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "flex flex-row place-items-center",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                width: 30,
                                                                height: 30,
                                                                src: "/logo-sosmed/linkedin.svg"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: " font-medium text-sm ml-2",
                                                                children: "wildan romiza"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "flex flex-row place-items-center",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                width: 30,
                                                                height: 30,
                                                                src: "/logo-sosmed/facebook.svg"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: " font-medium text-sm ml-2",
                                                                children: "wildan romiza"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "flex flex-row place-items-center",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                width: 30,
                                                                height: 30,
                                                                src: "/logo-sosmed/email.svg"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: " font-medium text-sm ml-2",
                                                                children: "wildan.romiza@gmail.com"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "mt-8 flex justify-center ",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            type: "button",
                                            onClick: ()=>setIsOpen(false),
                                            className: "inline-flex justify-center rounded-md border border-transparent bg-secondary/50 px-4 py-2 text-sm font-medium text-gray-600 hover:bg-secondary hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary focus-visible:ring-offset-2",
                                            children: "Got it, thanks!"
                                        })
                                    })
                                ]
                            })
                        })
                    })
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./components/year-card/index.js






function CardYear() {
    const setIsShowMonth = (0,cjs/* useSetRecoilState */.Zl)(atom/* showMonthContent */.qm);
    const setIsShowYear = (0,cjs/* useSetRecoilState */.Zl)(atom/* showYearContent */.Ud);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-row rounded-lg px-8 py-6",
            style: {
                backgroundImage: `linear-gradient(90deg, rgba(12, 173, 183, 0.7),rgba(230, 132, 110, 0.9)),url("/bg-profile.jpg")`,
                height: "fit-content",
                backgroundRepeat: "no-repeat",
                backgroundSize: "contain,cover"
            },
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "basis-2/3 flex flex-col",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            width: 50,
                            height: 51,
                            src: "/calendar-card.svg"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "font-bold text-6xl mt-4 text-white",
                            children: "2023"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "font-normal text-2xl mt-2 text-white",
                            children: "3 Project"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex basis-1/3 items-center justify-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        width: 50,
                        height: 51,
                        src: "/arrow.svg",
                        onClick: ()=>{
                            setIsShowMonth(true);
                            setIsShowYear(false);
                        }
                    })
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./components/month-card/index.js






function CardMonth() {
    const setIsShowMonth = (0,cjs/* useSetRecoilState */.Zl)(atom/* showMonthContent */.qm);
    const setIsShowProject = (0,cjs/* useSetRecoilState */.Zl)(atom/* showProjectContent */.kp);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-col rounded-lg px-8 py-6 bg-primary w-fit",
            style: {
                backgroundImage: `linear-gradient(180deg, rgba(12, 173, 183, 0.95),rgba(230, 132, 110, 0.9)),url("/bg-profile.jpg")`,
                height: "fit-content",
                backgroundRepeat: "no-repeat",
                backgroundSize: "contain,cover"
            },
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "basis-1/2 flex flex-col justify-center items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "font-bold text-4xl mt-4 text-white",
                            children: "January"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "font-normal text-2xl mt-2 text-white",
                            children: "3 Project"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                    className: "my-4"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex basis-1/2 items-center justify-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        width: 50,
                        height: 51,
                        src: "/arrow.svg",
                        onClick: ()=>{
                            setIsShowMonth(false);
                            setIsShowProject(true);
                        }
                    })
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./components/select-step-project/select-year/index.js





function SelectYear() {
    const setIsShowMonth = (0,cjs/* useSetRecoilState */.Zl)(atom/* showMonthContent */.qm);
    const setIsShowYear = (0,cjs/* useSetRecoilState */.Zl)(atom/* showYearContent */.Ud);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex-1 w-full mt-4 lg:grid grid-cols-5 gap-8 px-16 md:grid-cols-3 sm:grid-cols-1 ",
        children: /*#__PURE__*/ jsx_runtime_.jsx(CardYear, {})
    });
}

;// CONCATENATED MODULE: ./components/select-step-project/select-month/index.js



function SelectMonth() {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex-1 w-full mt-4 grid grid-cols-5 gap-8 px-16",
        children: /*#__PURE__*/ jsx_runtime_.jsx(CardMonth, {})
    });
}

;// CONCATENATED MODULE: ./app/(public)/project/page.js




















function Home() {
    let setSkillOpen = (0,cjs/* useSetRecoilState */.Zl)(atom/* showModalSkill */.uv);
    let setWorkOpen = (0,cjs/* useSetRecoilState */.Zl)(atom/* showModalWork */.sD);
    let setModalEducationOpen = (0,cjs/* useSetRecoilState */.Zl)(atom/* showModalEducation */.g);
    let setModalIntertestOpen = (0,cjs/* useSetRecoilState */.Zl)(atom/* showModalInterest */.f3);
    let setModalSocialMediaOpen = (0,cjs/* useSetRecoilState */.Zl)(atom/* showModalSocialMedia */.o7);
    const [isShowMonthContent, setShowMonthContent] = (0,cjs/* useRecoilState */.FV)(atom/* showMonthContent */.qm);
    const [isShowYearContent, setShowYearContent] = (0,cjs/* useRecoilState */.FV)(atom/* showYearContent */.Ud);
    const [isShowProjectContent, setIsShowProject] = (0,cjs/* useRecoilState */.FV)(atom/* showProjectContent */.kp);
    const renderSelectContent = ()=>{
        if (isShowYearContent) {
            return /*#__PURE__*/ jsx_runtime_.jsx(SelectYear, {});
        } else if (isShowMonthContent) {
            return /*#__PURE__*/ jsx_runtime_.jsx(SelectMonth, {});
        } else if (isShowProjectContent) {
            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "grid lg:grid-cols-5 mx-8 md:grid-cols-3 sm:grid-cols-1",
                children: /*#__PURE__*/ jsx_runtime_.jsx(project_card/* default */.Z, {})
            });
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: ` h-auto flex font-sans  flex-col flex-1 mb-8`,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col justify-center items-center flex-1 py-16",
                        style: {
                            backgroundImage: `linear-gradient(0deg, rgba(0, 0, 0,0.7), rgba(0, 0, 0,0.3)),url("/bg-profile.jpg")`,
                            height: "fit-content",
                            backgroundRepeat: "no-repeat",
                            backgroundSize: "contain,cover"
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "https://st3.depositphotos.com/1017228/18878/i/950/depositphotos_188781580-stock-photo-handsome-cheerful-young-man-standing.jpg",
                                width: 1200,
                                height: 1200,
                                className: "rounded-full w-36 h-36 object-cover "
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "mt-4 font-bold text-4xl text-white tracking-wide",
                                children: "M Wildan Romiza"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-semibold text-sm text-white ",
                                children: "Programmer"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: "font-normal text-normal text-white w-1/4 text-center mt-4",
                                children: [
                                    "I am a front-end programmer who is experienced and skilled in using Next.js technology. I enjoy creating attractive and easy-to-use user interfaces using a combination of HTML, CSS, and JavaScript.",
                                    " "
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-row space-x-4 mt-4 ",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        onClick: ()=>setSkillOpen(true),
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(IconButtonDescription, {
                                            src: "/skill.svg"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        onClick: ()=>setWorkOpen(true),
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(IconButtonDescription, {
                                            src: "/work.svg"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        onClick: ()=>setModalEducationOpen(true),
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(IconButtonDescription, {
                                            src: "/education.svg"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        onClick: ()=>setModalIntertestOpen(true),
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(IconButtonDescription, {
                                            src: "/interest.svg"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        onClick: ()=>setModalSocialMediaOpen(true),
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(IconButtonDescription, {
                                            src: "/sosmed.svg"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "font-medium text-center mt-8",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "font-extrabold text-xl",
                            children: "Portofolio's"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex h-0.5 mt-4 bg-gray-200 w-auto mx-16"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: renderSelectContent()
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ModalSkill, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(ModalWork, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(ModalEducation, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(ModalInterest, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(ModalSosmed, {})
        ]
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [225,719,499,738,990,137,234,464,442], () => (__webpack_exec__(8976)));
module.exports = __webpack_exports__;

})();